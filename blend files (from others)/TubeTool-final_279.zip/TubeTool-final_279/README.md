# TubeTool
generate tubing between two selected polygons.

![show utility](https://cloud.githubusercontent.com/assets/619340/7106310/2c154322-e13c-11e4-8258-1b58b9c7d360.gif)

## installation

you can `install from file`, with the zip selected.